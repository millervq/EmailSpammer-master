# EmailSpammer

Email Spammer en php solo descomprima el archivo ckeditor dentro de esta carpeta y subalo a su servidor con servicio smtp
